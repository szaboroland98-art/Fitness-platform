# ROLI SZABO – ONLINE COACHING (Landing Page)

Pagină de prezentare (Landing Page) pentru programul de **Online Coaching 1-la-1** creat de Roli Szabo.

## Structura proiectului

```text
roly-szabo-online-coaching/
├── index.html          # Structura principală a paginii
├── css/
│   └── style.css       # Stiluri custom, animații și tema Negru + Portocaliu
├── js/
│   └── main.js         # Meniu mobil, accordion FAQ, animații scroll și formular
├── images/
│   ├── poza-hero.jpg   # Poza principală din secțiunea Hero
│   ├── rezultat-1.jpg  # Transformare client #1
│   ├── rezultat-2.jpg  # Transformare client #2
│   ├── rezultat-3.jpg  # Transformare client #3
│   └── despre-mine.jpg # Poza din secțiunea Despre Mine
└── README.md           # Instrucțiuni de publicare pe GitHub Pages
```

## Cum publici site-ul gratuit pe GitHub Pages

1. Creează un repository nou pe **GitHub** (ex: `roly-szabo-coaching`).
2. Încarcă toate fișierele și folderele din acest proiect (`index.html`, `css/`, `js/`, `images/`, `README.md`).
3. Înlocuiește pozele din folderul `images/` cu fotografiile tale reale (păstrând exact aceleași denumiri: `poza-hero.jpg`, `rezultat-1.jpg`, `rezultat-2.jpg`, `rezultat-3.jpg`, `despre-mine.jpg`).
4. Intră în tab-ul **Settings** -> **Pages** al repository-ului tău GitHub.
5. La secțiunea **Branch**, selectează `main` (sau `master`) și folderul `/ (root)`, apoi apasă **Save**.
6. În 1-2 minute, site-ul tău va fi live la adresa `https://<username>.github.io/roly-szabo-coaching/`.

## Conectarea formularului la email (Opțional)

Pentru a primi aplicațiile direct pe email:
1. Creează un cont gratuit pe [Formspree.io](https://formspree.io/).
2. Copiază linkul formularului tău (ex: `https://formspree.io/f/xxxxxx`).
3. Deschide `index.html` și înlocuiește `action="#"` de la `<form id="coaching-form" action="#" ...>` cu linkul tău Formspree.
